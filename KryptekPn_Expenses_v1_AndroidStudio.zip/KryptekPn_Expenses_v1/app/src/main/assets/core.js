/* KryptekPn Expenses v1: deterministic, offline finance ledger. */
(function(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.KExpCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';
  const CATEGORIES = [
    {id:'credit-card', label:'Credit Card', symbol:'▣', color:'#BC9CFF'},
    {id:'petrol', label:'Petrol', symbol:'⛽', color:'#F5B96D'},
    {id:'food', label:'Food', symbol:'🍱', color:'#F58C9D'},
    {id:'hotel', label:'Hotel', symbol:'▤', color:'#79ACFA'},
    {id:'restaurant', label:'Restaurant', symbol:'🍽', color:'#8ED8C3'},
    {id:'friends', label:'Money Lent', symbol:'↗', color:'#E3BF7B'},
    {id:'others', label:'Others', symbol:'◇', color:'#A0ADB9'}
  ];
  const VALID_CATEGORIES = new Set(CATEGORIES.map(c => c.id));
  function newState() { return { version:1, transactions:[], settlements:[], settings:{defaultBudget:0, monthlyBudgets:{}} }; }
  function money(number) { const n=Number(number); if (!Number.isFinite(n)) throw new Error('Please enter a valid amount.'); const fixed=Math.round((n + Number.EPSILON)*100)/100; if (fixed <= 0 || fixed > 1000000000) throw new Error('Amount must be between ₹0.01 and ₹1,00,00,00,000.'); return fixed; }
  function cleanText(str, limit=140) { return String(str == null ? '' : str).replace(/[<>]/g, '').trim().slice(0,limit); }
  function dateValid(s) { if (!/^\d{4}-\d{2}-\d{2}$/.test(s || '')) return false; const [y,m,d]=s.split('-').map(Number); const dt=new Date(y,m-1,d); return dt.getFullYear()===y && dt.getMonth()===m-1 && dt.getDate()===d && y>=2000 && y<=2100; }
  function localDate(dt=new Date()) { const y=dt.getFullYear(), m=String(dt.getMonth()+1).padStart(2,'0'), d=String(dt.getDate()).padStart(2,'0'); return `${y}-${m}-${d}`; }
  function uid() { return 'k'+Date.now().toString(36)+Math.random().toString(36).slice(2,10); }
  function monthKey(date) { return date.slice(0,7); }
  function validState(raw) {
    if (!raw || raw.version!==1 || !Array.isArray(raw.transactions) || !Array.isArray(raw.settlements)) throw new Error('This is not a compatible KryptekPn Expenses v1 backup.');
    const clean = newState();
    const ids = new Set();
    for (const t of raw.transactions) {
      if (!t || typeof t.id!=='string' || ids.has(t.id) || !VALID_CATEGORIES.has(t.category) || !dateValid(t.date)) throw new Error('Backup contains invalid transactions.');
      ids.add(t.id);
      const amount=money(t.amount), type=t.category==='friends' ? 'lend' : 'expense';
      if (t.type!==type) throw new Error('Backup category does not match transaction type.');
      clean.transactions.push({ id:t.id, type, category:t.category, amount, date:t.date, note:cleanText(t.note,250), cardName:t.category==='credit-card' ? cleanText(t.cardName,50)||'Main Card' : '', friendName:t.category==='friends' ? cleanText(t.friendName,60)||'Friend' : '' });
    }
    for (const s of raw.settlements) {
      if (!s || typeof s.id!=='string' || ids.has(s.id) || !['card_payment','friend_repayment'].includes(s.type) || !dateValid(s.date)) throw new Error('Backup contains invalid settlements.');
      ids.add(s.id);
      if (s.type==='friend_repayment' && !clean.transactions.find(t => t.id===s.lendId && t.type==='lend')) throw new Error('Backup contains a repayment without a loan.');
      clean.settlements.push({id:s.id, type:s.type, amount:money(s.amount), date:s.date, note:cleanText(s.note,250), cardName:s.type==='card_payment' ? cleanText(s.cardName,50)||'Main Card' : '', lendId:s.type==='friend_repayment' ? s.lendId : ''});
    }
    const s=raw.settings||{};
    clean.settings.defaultBudget = Math.max(0,Math.min(1000000000, Number(s.defaultBudget)||0));
    if (s.monthlyBudgets && typeof s.monthlyBudgets === 'object') for (const [k,v] of Object.entries(s.monthlyBudgets)) if(/^\d{4}-(0[1-9]|1[0-2])$/.test(k) && Number.isFinite(Number(v)) && Number(v)>=0) clean.settings.monthlyBudgets[k]=Math.min(1000000000, Math.round(Number(v)*100)/100);
    // Check ledger-level invariants, even on imported backups.
    const outstandingCards = cardDues(clean); if (outstandingCards.some(c=>c.due < -0.001)) throw new Error('Backup contains card repayments exceeding charges.');
    if (friendDues(clean).some(f=>f.due < -0.001)) throw new Error('Backup contains friend repayments exceeding loans.');
    return clean;
  }
  function createTransaction(state,input) {
    if (!VALID_CATEGORIES.has(input.category)) throw new Error('Choose a category.');
    if (!dateValid(input.date)) throw new Error('Choose a valid date.');
    const isLend=input.category==='friends';
    const friend=isLend ? cleanText(input.friendName,60) : '';
    if (isLend && !friend) throw new Error('Enter your friend’s name.');
    const t={id:uid(), type:isLend?'lend':'expense', category:input.category, amount:money(input.amount), date:input.date, note:cleanText(input.note,250), cardName:input.category==='credit-card' ? cleanText(input.cardName,50)||'Main Card' : '', friendName:friend};
    state.transactions.push(t); return t;
  }
  function updateTransaction(state,id,input) {
    const idx=state.transactions.findIndex(t=>t.id===id); if (idx<0) throw new Error('Record not found.');
    const original=state.transactions[idx];
    // Editing settled records may compromise payment history; prevent it instead of silently changing debt.
    if (original.category==='friends' && state.settlements.some(s=>s.lendId===id)) throw new Error('Delete the repayments before editing this loan.');
    if (original.category==='credit-card' && state.settlements.some(s=>s.type==='card_payment' && s.cardName===original.cardName)) throw new Error('Delete card repayments before editing this card charge.');
    state.transactions.splice(idx,1);
    try {const revised=createTransaction(state,input); revised.id=id; return revised;}
    catch(e){state.transactions.splice(idx,0,original);throw e;}
  }
  function deleteTransaction(state,id) {
    const t=state.transactions.find(x=>x.id===id); if (!t) throw new Error('Record not found.');
    if (t.category==='credit-card' && state.settlements.some(s=>s.type==='card_payment' && s.cardName===t.cardName)) {
      const remaining=cardDues(state).find(x=>x.cardName===t.cardName)?.due||0;
      if (remaining + 0.001 < t.amount) throw new Error('First remove associated card payments before deleting this charge.');
    }
    state.transactions=state.transactions.filter(x=>x.id!==id);
    // Deleting a loan removes its associated repayments as one deliberate operation.
    if(t.type==='lend') state.settlements=state.settlements.filter(s=>s.lendId!==id);
    return t;
  }
  function cardDues(state) {
    const map=new Map();
    function get(k){if(!map.has(k))map.set(k,{cardName:k,charged:0,paid:0,due:0});return map.get(k);}
    for(const t of state.transactions) if(t.category==='credit-card')get(t.cardName||'Main Card').charged+=t.amount;
    for(const s of state.settlements) if(s.type==='card_payment')get(s.cardName||'Main Card').paid+=s.amount;
    return [...map.values()].map(c=>({...c, charged:round(c.charged), paid:round(c.paid), due:round(c.charged-c.paid)})).sort((a,b)=>b.due-a.due);
  }
  function friendDues(state) {
    return state.transactions.filter(t=>t.type==='lend').map(t=>{
      const repaid=round(state.settlements.filter(s=>s.type==='friend_repayment' && s.lendId===t.id).reduce((a,s)=>a+s.amount,0));
      return {...t,repaid,due:round(t.amount-repaid)};
    }).sort((a,b)=>b.due-a.due || b.date.localeCompare(a.date));
  }
  function round(x) {return Math.round((x+Number.EPSILON)*100)/100;}
  function totalCardDue(state) {return round(cardDues(state).reduce((s,c)=>s+Math.max(0,c.due),0));}
  function totalFriendDue(state) {return round(friendDues(state).reduce((s,f)=>s+Math.max(0,f.due),0));}
  function addCardPayment(state,input) {
    if(!dateValid(input.date))throw new Error('Choose a valid date.');
    const cardName=cleanText(input.cardName,50)||'Main Card', amount=money(input.amount), due=cardDues(state).find(c=>c.cardName===cardName)?.due||0;
    if(amount>due+0.001)throw new Error('Payment cannot exceed the card balance.');
    const s={id:uid(),type:'card_payment',date:input.date,amount,cardName,note:cleanText(input.note,250),lendId:''};state.settlements.push(s);return s;
  }
  function addFriendRepayment(state,input) {
    if(!dateValid(input.date))throw new Error('Choose a valid date.');
    const lend=friendDues(state).find(x=>x.id===input.lendId);
    if(!lend)throw new Error('Friend loan not found.');
    const amount=money(input.amount);
    if(amount>lend.due+0.001)throw new Error('Returned amount cannot exceed the outstanding balance.');
    const s={id:uid(),type:'friend_repayment',date:input.date,amount,lendId:lend.id,cardName:'',note:cleanText(input.note,250)};state.settlements.push(s);return s;
  }
  function deleteSettlement(state,id) { const n=state.settlements.length;state.settlements=state.settlements.filter(s=>s.id!==id);if(n===state.settlements.length)throw new Error('Settlement not found.'); }
  function periodStart(view,anchor) {
    if (!dateValid(anchor)) throw new Error('Invalid date');
    if(view==='day')return anchor;
    if(view==='month')return anchor.slice(0,7)+'-01';
    return anchor.slice(0,4)+'-01-01';
  }
  function shiftPeriod(view,anchor,shift) {
    const [y,m,d]=anchor.split('-').map(Number);
    if(view==='day')return localDate(new Date(y,m-1,d+shift));
    if(view==='month')return localDate(new Date(y,m-1+shift,1));
    return localDate(new Date(y+shift,0,1));
  }
  function inPeriod(date,view,anchor) {
    if(view==='day')return date===anchor;
    if(view==='month')return date.slice(0,7)===anchor.slice(0,7);
    return date.slice(0,4)===anchor.slice(0,4);
  }
  function periodTransactions(state,view,anchor) {
    return state.transactions.filter(t=>inPeriod(t.date,view,anchor)).sort((a,b)=>b.date.localeCompare(a.date));
  }
  function activity(state,view,anchor) {
    return [
      ...state.transactions.filter(t=>inPeriod(t.date,view,anchor)).map(t=>({...t,recordKind:'transaction'})),
      ...state.settlements.filter(s=>inPeriod(s.date,view,anchor)).map(s=>({...s,recordKind:'settlement'}))
    ].sort((a,b)=>b.date.localeCompare(a.date)||b.id.localeCompare(a.id));
  }
  function spendingTotal(state,view,anchor) {return round(periodTransactions(state,view,anchor).filter(t=>t.type==='expense').reduce((s,t)=>s+t.amount,0));}
  function lentTotal(state,view,anchor) {return round(periodTransactions(state,view,anchor).filter(t=>t.type==='lend').reduce((s,t)=>s+t.amount,0));}
  function categoryTotals(state,view,anchor) {
    const items=periodTransactions(state,view,anchor).filter(t=>t.type==='expense');
    return CATEGORIES.filter(c=>c.id!=='friends').map(c=>({...c,total:round(items.filter(t=>t.category===c.id).reduce((s,t)=>s+t.amount,0))})).filter(c=>c.total>0).sort((a,b)=>b.total-a.total);
  }
  function monthlyBudget(state,anchor) { const k=monthKey(anchor);const b=state.settings.monthlyBudgets[k];return b!==undefined?b:state.settings.defaultBudget; }
  function currency(n) { return '₹'+new Intl.NumberFormat('en-IN',{maximumFractionDigits:2}).format(Math.abs(round(Number(n)||0))); }
  function summary(state,view,anchor) { return {spent:spendingTotal(state,view,anchor),lent:lentTotal(state,view,anchor),cardDue:totalCardDue(state),friendDue:totalFriendDue(state),budget:monthlyBudget(state,anchor)}; }
  return {CATEGORIES,newState,validState,localDate,dateValid,money,cleanText,monthKey,createTransaction,updateTransaction,deleteTransaction,cardDues,friendDues,totalCardDue,totalFriendDue,addCardPayment,addFriendRepayment,deleteSettlement,shiftPeriod,inPeriod,periodTransactions,activity,spendingTotal,lentTotal,categoryTotals,monthlyBudget,currency,summary};
});
