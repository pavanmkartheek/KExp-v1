package com.kryptekpn.expenses;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.graphics.Color;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Offline-first Android shell for the KryptekPn Expenses v1 HTML app. */
public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 3101;
    private static final int CREATE_DOCUMENT_REQUEST = 3102;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingContent;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 13, 20));
        getWindow().setNavigationBarColor(Color.rgb(10, 13, 20));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(10, 13, 20));
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); // Required for bundled offline assets.
        settings.setAllowContentAccess(true); // Required for explicit backup imports.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new FileBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                return !"file".equalsIgnoreCase(url.getScheme()) ||
                       !url.toString().startsWith("file:///android_asset/");
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent chooser = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                chooser.setType("application/json");
                chooser.addCategory(Intent.CATEGORY_OPENABLE);
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(chooser, FILE_CHOOSER_REQUEST); }
                catch (ActivityNotFoundException ex) { fileCallback.onReceiveValue(null); fileCallback=null; return false; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class FileBridge {
        @JavascriptInterface public void saveFile(String filename, String content, String mime) {
            runOnUiThread(() -> {
                if (pendingContent != null) {
                    Toast.makeText(MainActivity.this, "Finish the current export first", Toast.LENGTH_SHORT).show();
                    return;
                }
                pendingContent = content;
                String cleanName=filename.replaceAll("[^a-zA-Z0-9_.-]", "_");
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType("text/csv".equals(mime)?"text/csv":"application/json");
                save.putExtra(Intent.EXTRA_TITLE, cleanName);
                try { startActivityForResult(save,CREATE_DOCUMENT_REQUEST); }
                catch(ActivityNotFoundException ex) {
                    pendingContent=null;
                    Toast.makeText(MainActivity.this, "No document picker available",Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode,resultCode,result);
        if(requestCode==FILE_CHOOSER_REQUEST) {
            if(fileCallback != null) {
                Uri[] selected = resultCode==RESULT_OK && result!=null && result.getData()!=null
                    ? new Uri[]{result.getData()} : null;
                fileCallback.onReceiveValue(selected);
                fileCallback=null;
            }
        } else if(requestCode==CREATE_DOCUMENT_REQUEST) {
            if(pendingContent!=null && resultCode==RESULT_OK && result!=null && result.getData()!=null) {
                try(OutputStream os=getContentResolver().openOutputStream(result.getData())) {
                    if(os==null)throw new IllegalStateException("Could not open file");
                    os.write(pendingContent.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Backup/export saved",Toast.LENGTH_SHORT).show();
                } catch(Exception ex) {
                    Toast.makeText(this,"Export failed: "+ex.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
            pendingContent=null;
        }
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("window.appBack ? window.appBack() : false", result -> {
            if (!"true".equals(result)) superBack();
        });
    }
    private void superBack(){super.onBackPressed();}
    @Override protected void onDestroy() {
        if (webView!=null) { webView.removeJavascriptInterface("Android");webView.destroy();webView=null; }
        super.onDestroy();
    }
}
