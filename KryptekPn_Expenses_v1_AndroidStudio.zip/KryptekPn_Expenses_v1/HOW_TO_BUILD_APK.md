# KryptekPn Expenses v1 APK — Android Studioలో Build చేయడం

## కావాల్సినవి

- Windows / Mac / Linuxలో Android Studio (free)
- Android SDK Platform 35 మరియు SDK Build Tools (Android Studio SDK Manager ద్వారా)
- JDK 17 (Android Studio bundled JDK ఉపయోగించవచ్చు)
- APK build సమయంలో Gradle dependencies download కోసం internet

## మొదటి పద్ధతి — Projectను నేరుగా తెరవడం

1. ZIP extract చేసి `KryptekPn_Expenses_v1` folderని Android Studioలో **File > Open** ద్వారా తెరవండి.
2. ఈ projectలో Gradle wrapper JAR binary లేదు. అందువల్ల మీ కంప్యూటర్‌లో Gradle install అయి ఉంటే sync చేయవచ్చు. లేకపోతే రెండో పద్ధతి ఉపయోగించండి.
3. Gradle 8.9, Android Gradle Plugin 8.7.3, Java 17, SDK 35 సరిపడేలా config ఉంది.
4. Sync విజయవంతమైన తర్వాత **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. `app/build/outputs/apk/debug/app-debug.apk` install చేయవచ్చు.

## రెండో పద్ధతి — Android Studio fresh project నుంచి wrapper తీసుకోవడం (Recommended)

1. Android Studioలో **New Project > Empty Views Activity** ఎంచుకోండి. **Java**, minimum SDK 26, app name `KryptekPn Expenses` పెట్టండి.
2. కొత్తగా Android Studio సృష్టించిన projectలో ఈ files వస్తాయి: `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`.
3. ఆ కొత్త project నుంచి `gradle/wrapper/gradle-wrapper.jar`ని, అవసరమైతే `gradlew` మరియు `gradlew.bat` scriptsని **ఈ KryptekPn_Expenses_v1 projectలో corresponding foldersకి** copy చేయండి. ఇది Google/Gradle build processకి చెందిన wrapper bootstrap; దీన్ని మన packageలో embed చేయలేదు.
4. Android Studioలో `KryptekPn_Expenses_v1`ని ఓపెన్ చేసి Gradle Sync చేయండి. SDK 35 missing అని వస్తే SDK Manager నుంచి install చేయండి.
5. Android Studio > **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Output: `app/build/outputs/apk/debug/app-debug.apk`.
7. Android phoneలో APKని install చేసి Home / Dues / Add Expense / Settings / backup import-export workflow పరీక్షించండి.

## Command-line alternative

Gradle 8.9, Android SDK 35 ఇప్పటికే setup అయి ఉంటే project rootలో:

```bash
gradle assembleDebug
```

లేదా wrapper JAR ఉన్నపుడు Windows PowerShellలో:

```powershell
.\gradlew.bat assembleDebug
```

## Troubleshooting

- `GradleWrapperMain not found` -> పైన చెప్పిన wrapper JAR copy చేయండి.
- `SDK location not found` -> Android Studio SDK Managerలో SDK 35 install చేసి, IDE ద్వారా sync చేయండి.
- `Unsupported Java` -> Gradle JDK 17 ఎంచుకోండి.
- Android app తొలగించే ముందు Settingsలో JSON backup తీసుకోవడం మంచిది.
