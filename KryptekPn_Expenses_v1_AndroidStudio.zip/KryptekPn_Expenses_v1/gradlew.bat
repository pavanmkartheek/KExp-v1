@echo off
setlocal
cd /d "%~dp0"
if exist "gradle\wrapper\gradle-wrapper.jar" (
    java -classpath "gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
) else (
    where gradle >nul 2>nul
    if errorlevel 1 (
        echo Gradle Wrapper JAR is missing. Open HOW_TO_BUILD_APK.md for setup.
        exit /b 1
    )
    gradle %*
)
endlocal
