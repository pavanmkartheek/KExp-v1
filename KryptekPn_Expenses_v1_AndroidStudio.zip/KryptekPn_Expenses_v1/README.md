# KryptekPn Expenses — KExp v1.0

ఇది Android కోసం రూపొందించిన **offline-first personal expense tracker**. App పేరు `KryptekPn Expenses`, icon/brand `KExp`.

## v1లో ఉన్న సదుపాయాలు

- **Daily / Monthly / Yearly** filter, ముందు/తర్వాత date periods చూడడం.
- **ప్రతి కొత్త నెలలో monthly spending ఆటోమేటిక్‌గా ₹0 నుంచి మొదలు**; గత నెల records తొలగిపోవు.
- Default monthly budget మరియు ప్రత్యేకమైన నెలకు budget override.
- ఖర్చుల categories: Credit Card, Petrol, Food, Hotel, Restaurant, Money Lent (Friends), Others.
- Others categoryలో ఏ ఖర్చో notes రాయవచ్చు.
- Credit Card categoryలో charges, ప్రతి card పేరు, pending amount, full/partial payments.
- Friendsకి ఇచ్చిన డబ్బు, friend పేరు, ఎంత రావాలి, full/partial returns.
- Card repayments **మళ్లీ expensesలో లెక్కించబడవు**.
- Friendsకి ఇచ్చిన డబ్బు expenseలో కాకుండా **return రావాల్సిన money**గా లెక్కించబడుతుంది.
- Dues నెల మారినా carry-forward అవుతాయి; monthly expense మాత్రం fresh start.
- Activity history, edit/delete, spending breakdown chart.
- Offline local storage, JSON backup/restore, CSV export.
- ఒక buttonతో sample/demo data (నిజమైన entries లేకపోతే మాత్రమే).

## వెంటనే Preview చూడడానికి

`KExp_v1_Offline_Demo.html` ని Chromeలో తెరవండి. ఇది internet లేకుండా పనిచేసే standalone demo; దాని browserలోనే data save అవుతుంది. Android appలోని screens, logic ఒకటే. Browser storage clear చేస్తే demo data పోవచ్చు.

## APK Build

`HOW_TO_BUILD_APK.md` చూడండి. Android Studioలో Android SDK, Gradle setup చేసి **Build > Build Bundle(s) / APK(s) > Build APK(s)** చేయాలి. Debug APK సాధారణంగా `app/build/outputs/apk/debug/app-debug.apk` వద్ద వస్తుంది.

**ఈ environmentలో Android SDK/Gradle లేకపోవడంతో binary APK build చేసి పరీక్షించలేదు.** Functional HTML screens, JavaScript ledger automated tests ఇక్కడ పరిశీలించబడ్డాయి. Android deviceలో final buildని పరీక్షించాలి.

## Data & privacy

- Data కేవలం appలోని local WebView storageలో ఉంటుంది.
- Internet permission లేదా remote server లేదు.
- JSON backup తీసుకోకుండా app uninstall చేస్తే / app data clear చేస్తే data పోవచ్చు.
- ఈ v1లో automatic cloud sync, OTP/login, bank integration, bills reminders లేవు.

## Files

- `app/src/main/assets/` — UI and accounting logic.
- `app/src/main/java/` — Android WebView shell, native file save/import.
- `app/src/main/res/drawable/kexp_icon.png` — KExp logo.
- `tests/test_core.js` — accounting logic tests.

## Accounting definition

`Monthly Expenses = సాధారణ categories + Credit Card charges` (Friendsకి ఇచ్చిన డబ్బు తప్ప).

`Credit Card Due = Total Card Charges − Total Recorded Card Payments` (all months).

`Friends Owe You = Total Money Lent − Total Money Received Back` (all months).

**గమనిక:** ఇదొక manual tracker. Bank/Card statements నుంచి amounts ఆటోమేటిక్‌గా రావు; మీరు ఇచ్చిన entries ఆధారంగా మాత్రమే dues చూపిస్తుంది.
