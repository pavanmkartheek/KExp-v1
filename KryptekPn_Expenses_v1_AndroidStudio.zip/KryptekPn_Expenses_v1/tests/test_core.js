const assert = require('node:assert/strict');
const K = require('../app/src/main/assets/core.js');
let s=K.newState();
assert.equal(K.spendingTotal(s,'month','2026-11-19'),0);
assert.equal(K.totalCardDue(s),0);
K.createTransaction(s,{amount:1000,category:'petrol',date:'2026-10-25',note:'fuel'});
K.createTransaction(s,{amount:300,category:'food',date:'2026-11-01',note:'breakfast'});
K.createTransaction(s,{amount:2500,category:'credit-card',date:'2026-11-02',cardName:'HDFC',note:'laptop'});
const loan=K.createTransaction(s,{amount:6000,category:'friends',date:'2026-10-15',friendName:'Ravi',note:'lent'});
assert.equal(K.spendingTotal(s,'month','2026-11-19'),2800);
assert.equal(K.spendingTotal(s,'month','2026-10-19'),1000); // fresh month
assert.equal(K.lentTotal(s,'month','2026-10-19'),6000);
assert.equal(K.totalFriendDue(s),6000); // loan persists in November
assert.equal(K.totalCardDue(s),2500);
K.addFriendRepayment(s,{amount:1000,lendId:loan.id,date:'2026-11-05',note:'UPI'});
K.addCardPayment(s,{amount:1500,cardName:'HDFC',date:'2026-12-01'});
assert.equal(K.totalFriendDue(s),5000);
assert.equal(K.totalCardDue(s),1000);
assert.equal(K.spendingTotal(s,'month','2026-12-18'),0); // card payoff not double-counted
assert.equal(K.spendingTotal(s,'year','2026-11-19'),3800);
assert.equal(K.activity(s,'month','2026-12-19').length,1);
assert.throws(()=>K.addCardPayment(s,{amount:1001,cardName:'HDFC',date:'2026-12-02'}));
assert.throws(()=>K.addFriendRepayment(s,{amount:5001,lendId:loan.id,date:'2026-12-02'}));
assert.equal(K.shiftPeriod('month','2026-12-14',1),'2027-01-01');
assert.equal(K.shiftPeriod('day','2026-12-31',1),'2027-01-01');
assert.equal(K.shiftPeriod('year','2026-12-31',1),'2027-01-01');
assert.equal(K.validState(JSON.parse(JSON.stringify(s))).transactions.length,4);
assert.equal(K.monthlyBudget(s,'2026-11-19'),0);
s.settings.defaultBudget=5000;
s.settings.monthlyBudgets['2026-11']=8000;
assert.equal(K.monthlyBudget(s,'2026-10-19'),5000);
assert.equal(K.monthlyBudget(s,'2026-11-19'),8000);
assert.throws(()=>K.createTransaction(s,{amount:-5,category:'food',date:'2026-11-03'}));
assert.throws(()=>K.createTransaction(s,{amount:50,category:'friends',date:'2026-11-03',friendName:''}));
assert.throws(()=>K.createTransaction(s,{amount:50,category:'food',date:'2026-02-30'}));
let invalid=JSON.parse(JSON.stringify(s));invalid.settlements.push({...invalid.settlements[0],id:'different',amount:9000});assert.throws(()=>K.validState(invalid));
console.log('PASS: all finance ledger and rollover tests');
